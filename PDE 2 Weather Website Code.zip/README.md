<h1>WeatherCast</h1>
  
  We are building simple weather  website where it can show weather related details.
  this is an team project 
  
  <h2> Check Website here </h2>
  https://amuejunankar.github.io/WeatherCast/
  
<h3> //  Here are the team members //</h3>
 1 > Amit Junankar     <br />
 2 > Gaurav Kude       <br />
 3 > Rutuja Bhumare    <br />
 4 > Sarang Tadaskar   <br />
 5 > Neha Kukade
  
